// Simple Alumni class using plain JS objects (in-memory store)
class Alumni {
    constructor({ id, name, email, password, batch, job, eventName, registeredOn }) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.batch = batch;
        this.job = job;
        this.eventName = eventName;
        this.registeredOn = registeredOn;
    }
}

module.exports = Alumni;
