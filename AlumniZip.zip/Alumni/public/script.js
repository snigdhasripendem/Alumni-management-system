// Register handler
document.getElementById("registerForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const alumni = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
        batch: document.getElementById("batch").value,
        job: document.getElementById("job").value
    };

    try {
        const res = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(alumni)
        });

        if (res.ok) {
            alert('Registered successfully. Please login.');
            window.location.href = 'login.html';
        } else {
            const text = await res.text();
            alert('Registration failed: ' + text);
        }
    } catch (err) {
        console.error(err);
        alert('Network error during registration');
    }
});

// Login handler
document.getElementById("loginForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const loginData = {
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    };

    try {
        const res = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginData)
        });

        if (res.ok) {
            const user = await res.json();
            sessionStorage.setItem('alumniUser', JSON.stringify({
                id: user.id,
                name: user.name,
                email: user.email
            }));
            window.location.href = 'dashboard1.html';
        } else {
            const text = await res.text();
            alert('Login failed: ' + text);
        }
    } catch (err) {
        console.error(err);
        alert('Network error during login');
    }
});

// Optionally expose a logout helper
window.alumniLogout = function() {
    sessionStorage.removeItem('alumniUser');
    window.location.href = 'index.html';
};

// Dashboard/Event list: load, render, filters
window.alumniData = [];

async function loadAlumni() {
    try {
        const res = await fetch('/api/alumni');
        if (!res.ok) throw new Error('Failed to fetch alumni');

        const data = await res.json();
        window.alumniData = data || [];
        renderAlumni();
        populateFilters();
    } catch (err) {
        console.error('Error loading alumni', err);
        const list = document.getElementById('alumniList');
        if (list) list.innerHTML = '<li class="empty">Unable to load alumni</li>';
    }
}

function renderAlumni() {
    const list = document.getElementById('alumniList');
    if (!list) return;

    const q = document.getElementById('searchInput')?.value?.toLowerCase()?.trim() || '';
    const batch = document.getElementById('batchFilter')?.value || '';
    const job = document.getElementById('jobFilter')?.value || '';

    let filtered = window.alumniData.slice();

    if (q) {
        filtered = filtered.filter(a =>
            (a.name || '').toLowerCase().includes(q) ||
            (a.email || '').toLowerCase().includes(q) ||
            (a.job || '').toLowerCase().includes(q) ||
            (a.batch || '').toLowerCase().includes(q) ||
            (a.eventName || '').toLowerCase().includes(q) ||
            formatDate(a.registeredOn).toLowerCase().includes(q)
        );
    }

    if (batch) filtered = filtered.filter(a => (a.batch || '') === batch);
    if (job) filtered = filtered.filter(a => (a.job || '') === job);

    if (filtered.length === 0) {
        list.innerHTML = '<li class="empty">No alumni match your query</li>';
        return;
    }

    list.innerHTML = '';

    filtered.forEach(a => {
        const li = document.createElement('li');
        li.className = 'alum-card';

        const initials = (a.name || '')
            .split(' ')
            .map(s => s[0])
            .join('')
            .slice(0, 2)
            .toUpperCase();

        const avatar = `<div class="avatar" aria-hidden="true">${initials || 'A'}</div>`;
        const memberName = escapeHtml(a.name || '-');
        const memberRole = escapeHtml(a.job || 'Community Member');
        const memberEmail = escapeHtml(a.email || '');
        const memberBatch = escapeHtml(a.batch || 'Not specified');
        const eventName = escapeHtml(a.eventName || 'Annual Alumni Meet 2026');
        const registeredOn = escapeHtml(formatDate(a.registeredOn));

        li.innerHTML = `
            <div class="card-row">
                ${avatar}
                <div class="card-body">
                    <div class="card-title">${memberName}</div>
                    <div class="card-sub">${memberRole}</div>
                    <div class="card-event">Registered for ${eventName}</div>
                    <div class="card-meta">${memberEmail} | Batch: ${memberBatch}</div>
                    <div class="card-date">Registration date: ${registeredOn}</div>
                </div>
            </div>
        `;

        list.appendChild(li);
    });
}

function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function(c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
}

function formatDate(value) {
    if (!value) return 'Not available';

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return 'Not available';

    return date.toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function setupDashboardControls() {
    if (!document.getElementById('alumniList')) return;

    document.getElementById('searchInput')?.addEventListener('input', () => renderAlumni());
    document.getElementById('batchFilter')?.addEventListener('change', () => renderAlumni());
    document.getElementById('jobFilter')?.addEventListener('change', () => renderAlumni());
    document.getElementById('refreshBtn')?.addEventListener('click', () => loadAlumni());
}

function populateFilters() {
    const batchSel = document.getElementById('batchFilter');
    const jobSel = document.getElementById('jobFilter');
    if (!batchSel && !jobSel) return;

    const batches = new Set();
    const jobs = new Set();

    window.alumniData.forEach(a => {
        if (a.batch) batches.add(a.batch);
        if (a.job) jobs.add(a.job);
    });

    if (batchSel) {
        const prev = batchSel.value || '';
        batchSel.innerHTML = '<option value="">All batches</option>' +
            [...batches].map(b => `<option value="${escapeHtml(b)}">${escapeHtml(b)}</option>`).join('');
        batchSel.value = prev;
    }

    if (jobSel) {
        const prev = jobSel.value || '';
        jobSel.innerHTML = '<option value="">All jobs</option>' +
            [...jobs].map(j => `<option value="${escapeHtml(j)}">${escapeHtml(j)}</option>`).join('');
        jobSel.value = prev;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('alumniList')) {
        const user = sessionStorage.getItem('alumniUser');
        if (user) {
            const u = JSON.parse(user);
            document.getElementById('greeting').innerText = `Welcome, ${u.name} (${u.email})`;
        }

        setupDashboardControls();
        loadAlumni();
    }
});
