const express = require('express');
const cors = require('cors');

const app = express();

// Middleware
app.use(express.json());
app.use(cors());
app.use(express.static('public')); // serve frontend files from /public

// 🔗 Import Routes (these use an in-memory JS object store)
const alumniRoutes = require('./routes/alumniRoutes');

// 🔗 Use Routes
app.use('/api', alumniRoutes);

// � Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});