const express = require('express');
const router = express.Router();
const Alumni = require('../models/Alumni');

// Dummy in-memory data (for testing without DB)
let alumniList = [];
const DEFAULT_EVENT_NAME = 'Annual Alumni Meet 2026';

// 🧪 Test Route
router.get('/test', (req, res) => {
    res.send('Alumni route is working!');
});

// 📝 Register Alumni
router.post('/register', (req, res) => {
    const { name, email, password, batch, job } = req.body || {};

    if (!name || !email || !password) {
        return res.status(400).send('Name, email and password are required');
    }

    // Check duplicate email
    if (alumniList.find(a => a.email === email)) {
        return res.status(409).send('Email already registered');
    }

    const newAlum = new Alumni({
        id: alumniList.length + 1,
        name,
        email,
        password,
        batch: batch || '',
        job: job || '',
        eventName: DEFAULT_EVENT_NAME,
        registeredOn: new Date().toISOString()
    });

    alumniList.push(newAlum);
    return res.status(201).json({ message: 'Registered successfully', id: newAlum.id });
});

// 🔐 Login
router.post('/login', (req, res) => {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).send('Email and password required');

    const user = alumniList.find(a => a.email === email && a.password === password);

    if (user) {
        // do not send password back
        const { password, ...safe } = user;
        return res.json(safe);
    }

    return res.status(401).send('Invalid Credentials');
});

// 📋 Get All Alumni
router.get('/alumni', (req, res) => {
    // return list without passwords
    const safeList = alumniList.map(({ password, ...rest }) => rest);
    res.json(safeList);
});

module.exports = router;
